# Changelog

## 1.0.0 (2025-02-22)

### Features
- Initial release