# Usage

```js
const db = require('advanced-db');
db.connect('sqlite://db.sqlite');
```