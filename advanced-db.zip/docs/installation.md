# Installation

```bash
npm install advanced-db
```